public interface CallBack {
        void callBackMethod(Object obj);
}