package cl;

public interface CallBack {
    void getResponse(Object obj);
}