package svpa;

public interface CallBack {
    void getResponse(Object obj, Object cgv);
}