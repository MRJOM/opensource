package application;

public interface CallBack {
    void getResponse(Object obj);
}